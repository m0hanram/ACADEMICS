a = int(input("enter the value of a "))
aa = 10*a + a
aaa = 100*a + aa
aaaa = 1000*a + aaa
print(a+aa+aaa+aaaa)

